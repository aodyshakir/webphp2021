<?php

echo "Besm Allah";