<li class="active">التحكم بالاقسام</li>
<li><a href="addcat.php">اضف قسم</a></li>
<li><a href="vactivecats.php">الاقسام المفعلة</a></li>
<li><a href="vunactivecats.php">الاقسام غير المفعلة</a></li>

<li class="active">التحكم بالمنتجات</li>
<li><a href="addproduct.php">اضف منتج جديد</a></li>
<li><a href="viewaproduct.php">المنتجات المفعلة</a></li>
<li><a href="vunactiveproduct.php">المنتجات غير المفعلة</a></li>

<li class="active">التحكم بمدراء الموقع</li>
<li><a href="addadmin.php">اضف مدير جديد</a></li>
<li><a href="viewadmin.php">المدرين الموجودين</a></li>

<li class="active">التحكم برفع الصور</li>
<li><a href="upload.php">رفع صورة جديد</a></li>
<li><a href="viewfile.php">التحكم بالصور الموجودة</a></li>
