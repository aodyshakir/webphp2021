<?php
$config=array (
//Genral Vars.
"site_name" => "���� ������� ���� ����",
"site_path" => "C:\Inetpub/wwwroot/dradelshalaby/",
"site_url"  => "http://127.0.0.1/dradelshalaby/",
"index_file"  => "index.php",
"images_url"  => "http://127.0.0.1/dradelshalaby/images/hebo/",
"site_domin"  => "127.0.0.1",
"images_path"  => "./images/hebo/books/",
//Data Base Vars.
"db_name"  => "books",
"db_user"  => "root",
"db_pass"  => "root",
"db_host"  => "127.0.0.1",
);


?>