<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
الصفحات الرئيسية</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="index.php">الصفحة الرئيسية</a></td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="index.php">الإفتتاحية</a></td>
		</tr>
		
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="why.php">كلمة مدير المعهد</a></td>
		</tr>
		
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="readme.php">تعرف علينا</a></td>
		</tr>
	
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
الكادر الوظيفي</td>
		</tr>
	
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
الحلول التكنولوجية</td>
		</tr>
	<tr>
			
			<td valign="top" height="100%" id="menuadmin">
ملاحظات عامة</td>
		</tr>
	</table>
</div>
<br>
<br>

<div align="center">
	<table  width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
قسم الدورات</td>
		</tr>
		<tr>
			<td valign="top" height="100%" id="menuadmin">
طلبات التسجيل بالدورات</td>
		</tr>
	
		<tr>
			<td valign="top" height="100%" id="menuadmin">
الدورات المفعلة</td>
		</tr>
	
		<tr>
			<td valign="top" height="100%" id="menuadmin">
الدورات غير المفعلة</td>
		</tr>
	
		<tr>
			<td valign="top" height="100%" id="menuadmin">
إضافة دورة</td>
		</tr>
	
		<tr>
			<td valign="top" height="100%" id="menuadmin">
إضافة قسم</td>
		</tr>
	
		<tr>
			<td valign="top" height="100%" id="menuadmin">
الأقسام المفعلة</td>
		</tr>
	
		<tr>
			<td valign="top" height="100%" id="menuadmin">
الأقسام غير المفعلة</td>
		</tr>
	
	</table>
</div>


<br>


<div align="center">
	<table  width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
قسم الوظائف</td>
		</tr>
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="addarticle.php">طلبات التوظيف</a></td>
		</tr>
		
			<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="delarticle.php">الوظائف المفعلة</a></td>
		</tr>
	<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="viewnotactive.php">الوظائف غير المفعلة</a></td>
		</tr>
		
		
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="viewactive.php">إضافة وظيفة</a></td>
		</tr>
		
		
		<tr>
			<td valign="top" height="100%" id="menuadmin">
إضافة قسم</td>
		</tr>
		
		
		<tr>
			<td valign="top" height="100%" id="menuadmin">
الأقسام المفعلة</td>
		</tr>
		
		
		<tr>
			<td valign="top" height="100%" id="menuadmin">
الأقسام غير المفعلة</td>
		</tr>
	</table>
</div>


<br>


<div align="center">
	<table  width="183" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
قسم الأخبار</td>
		</tr>
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="addbook.php">إضافة خبر</a></td>
		</tr>
		
			<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="delbook.php">الأخبار المفعلة</a></td>
		</tr>
	<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="notactivebooks.php">الأخبار غير المفعلة</a></td>
		</tr>
		
		
		
	</table>
</div>


<br>


<div align="center">
	<table  width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh" >
&nbsp;دليل المواقع 


			</td>
		</tr>
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="addsite.php">
إضافة موقع 

</a>
			</td>
		</tr>
		
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="delsite.php">
حذف موقع 

</a>
			</td>
		</tr>
	<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewsites.php">
عرض المواقع 

</a>
			</td>
		</tr>
	</table>
</div>


<br>


<div align="center">
	<table  width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
معرض الصور</td>
		</tr>
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="upload_l_photo.php">رفع صورة لمعرض الصور</a></td>
		</tr>
		
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="addphoto.php">إضافة صورة</a></td>
		</tr>
	<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="delphoto.php">حذف صورة</a></td>
		</tr>
	</table>
</div>

<br>


<div align="center">
	<table  width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
رفع الصور</td>
		</tr>
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="addsign.php">رفع صورة إلي معرض الصور</a></td>
		</tr>
		
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="delsign.php">رفع صورة لقسم الأخبار</a></td>
		</tr>
	<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewsign.php">رفع صورة عامة</a></td>
		</tr>
	</table>
</div>
<br>