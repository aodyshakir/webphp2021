<?include_once ("session.php");?>
<?
require_once ("lib/mysql.php");
require_once ("./conn.php");
?>

<html dir="rtl">
<head>
<link rel="stylesheet" type="text/css" href="style.css" >
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="copyright" content="Developed and Designed By ahmed abu_eldahab Copyright &copy; dahabit@gmail.com development" />

<title>معهد الجبيل الثقافي</title>

</head>


<body BGCOLOR=#F5F5F5 LEFTMARGIN=0 TOPMARGIN=15 MARGINWIDTH=0 MARGINHEIGHT=0>
	<!-- border -->

			
			
			
<!-- header -->

<!-- header -->




	<!-- border -->

<div align="center">
	<table border="0" width="750" cellspacing="0" cellpadding="10" dir="ltr"  id="bordertbl">
	
		<tr>
			<td   width=100%  height="100%">
			
	<!-- ImageReady Slices (headertest.psd) -->		

	
<!-- ImageReady Slices (header.psd) -->



	
	
			
			<!-- border -->


<!-- news -->



<p> </p>







<!-- star body-->
<table border="0" width="750"  dir="rtl" cellspacing="0" cellpadding="0">
	<tr>
		<td width="180" align="right" valign="top" >
		
		
		
			<!--menu -->
		
	<?php include_once ("menu.php");?>
		
		
		<!--menu -->
		
		
		
		</td>
		<td width="565" align="center" valign="top" id="mainarea3">