<? include_once("includes/header.php");


 ?><br><br>
<TABLE  WIDTH=516 HEIGHT=263 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD WIDTH=516 HEIGHT=100% COLSPAN=6 id="allpages">		
<br><br>
<br><br>
<br><br>
���� �����
<br><br>
<br><br>
<br><br>
		
</td></tr></table>

<?include_once("includes/footer.php"); ?>