<?
header("Location: index.php");
 ?>