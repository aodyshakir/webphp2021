﻿<?php
 include_once './include/header.php' ;
?>

<br>
<br>
<br>
<div align ="left">
<a href="./g/main.html" >
Please click here to view gallery

</a>

</div>
<?
 include_once './include/footer.php' ; 
 
?>