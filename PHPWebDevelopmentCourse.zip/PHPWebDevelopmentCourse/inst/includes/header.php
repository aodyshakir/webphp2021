<?
ob_start();
session_start();
require_once ("mysql.php");
require_once ("conn.php");
?>
<html dir="rtl">
<head>
<link rel="stylesheet" type="text/css" href="style.css" >
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects"></script>

<script type="text/javascript" src="js/lightbox.js"></script>
<meta name="copyright" content="Developed and Designed By ahmed abu_eldahab Copyright &copy; dahabit@gmail.com development" />

<title>معهد الجبيل الثقافي</title>

</head>



<body  LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 >

<!-- header -->
	
<div align="center">
	<table  width="750" cellspacing="0" cellpadding="0" dir="ltr" id="main_table">
		<tr>
			<td>

<!-- header -->
<div align="center">
<!-- ImageReady Slices (header.psd) -->
<table  width="751" height="181" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="2">
			<a href="contactus.php"
				onmouseover="window.status='إتصل بنا';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/header/header_01.gif" width="45" height="21" border="0" alt="إتصل بنا"></a></td>
		<td>
			<img src="images/header/header_02.gif" width="7" height="21" alt=""></td>
		<td colspan="2">
			<a href="index.php"
				onmouseover="window.status='الصفحة الرئيسية';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/header/header_03.gif" width="38" height="21" border="0" alt="الصفحة الرئيسية"></a></td>
		<td>
			<img src="images/header/header_04.gif" width="9" height="21" alt=""></td>
		<td colspan="14">
			<img src="images/header/header_05.gif" width="651" height="21" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="21" alt=""></td>
	</tr>
	<tr>
		<td colspan="20">
			<img src="images/header/header_06.gif" width="750" height="30" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="30" alt=""></td>
	</tr>
	<tr>
		<td colspan="20">
			<img src="images/header/header_07.gif" width="750" height="33" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="33" alt=""></td>
	</tr>
	<tr>
		<td colspan="20">
			<img src="images/header/header_08.gif" width="750" height="25" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="25" alt=""></td>
	</tr>
	<tr>
		<td colspan="20">
			<img src="images/header/header_09.gif" width="750" height="20" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="20" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2">
			<img src="images/header/header_10.gif" width="25" height="22" alt=""></td>
		<td colspan="3" rowspan="2">
			<a href="photos.php"
				onmouseover="window.status='المعرض';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/header/header_11.gif" width="56" height="22" border="0" alt="المعرض"></a></td>
		<td colspan="3" rowspan="3">
			<img src="images/header/header_12.gif" width="32" height="23" alt=""></td>
		<td rowspan="3">
			<a href="news.php"
				onmouseover="window.status='أخبار';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/header/header_13.gif" width="52" height="23" border="0" alt="أخبار"></a></td>
		<td rowspan="2">
			<img src="images/header/header_14.gif" width="34" height="22" alt=""></td>
		<td rowspan="2">
			<a href="view_jobs.php"
				onmouseover="window.status='وظائف';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/header/header_15.gif" width="51" height="22" border="0" alt="وظائف"></a></td>
		<td rowspan="3">
			<img src="images/header/header_16.gif" width="31" height="23" alt=""></td>
		<td rowspan="2">
			<a href="branches.php"
				onmouseover="window.status='الفروع';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/header/header_17.gif" width="53" height="22" border="0" alt="الفروع"></a></td>
		<td rowspan="2">
			<img src="images/header/header_18.gif" width="25" height="22" alt=""></td>
		<td rowspan="2">
			<a href="train.php"
				onmouseover="window.status='الدورات';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/header/header_19.gif" width="62" height="22" border="0" alt="الدورات"></a></td>
		<td rowspan="4">
			<img src="images/header/header_20.gif" width="229" height="35" alt=""></td>
		<td colspan="5">
			<img src="images/header/header_21.gif" width="100" height="12" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="12" alt=""></td>
	</tr>
	<tr>
		<td rowspan="3">
			<img src="images/header/header_22.gif" width="12" height="23" alt=""></td>
		<td rowspan="3">
			<a href="./en/">
				<img src="images/header/header_22-24.gif" width="30" height="23" border="0" alt=""></a></td>
		<td rowspan="3">
			<img src="images/header/header_24.gif" width="10" height="23" alt=""></td>
		<td rowspan="3">
			<a href="index.php">
				<img src="images/header/header_24-26.gif" width="31" height="23" border="0" alt=""></a></td>
		<td rowspan="3">
			<img src="images/header/header_26.gif" width="17" height="23" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="10" alt=""></td>
	</tr>
	<tr>
		<td colspan="4" rowspan="2">
			<img src="images/header/header_27.gif" width="81" height="13" alt=""></td>
		<td colspan="2" rowspan="2">
			<img src="images/header/header_28.gif" width="85" height="13" alt=""></td>
		<td colspan="2" rowspan="2">
			<img src="images/header/header_29.gif" width="78" height="13" alt=""></td>
		<td rowspan="2">
			<img src="images/header/header_30.gif" width="62" height="13" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="1" alt=""></td>
	</tr>
	<tr>
		<td colspan="4">
			<img src="images/header/header_31.gif" width="84" height="12" alt=""></td>
		<td>
			<img src="images/header/header_32.gif" width="31" height="12" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="12" alt=""></td>
	</tr>
	<tr>
		<td colspan="20">
			<img src="images/header/header_33.gif" width="750" height="16" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="1" height="16" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/header/spacer.gif" width="25" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="20" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="7" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="29" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="9" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="9" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="14" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="52" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="34" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="51" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="31" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="53" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="25" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="62" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="229" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="12" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="30" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="10" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="31" height="1" alt=""></td>
		<td>
			<img src="images/header/spacer.gif" width="17" height="1" alt=""></td>
		<td></td>
	</tr>
</table>
<!-- End ImageReady Slices -->

</div>



<!-- star body-->
<table border="0" width="750"  dir="rtl" cellspacing="0" cellpadding="0">
	<tr>
		<td width="180" align="right" valign="top" >
		
		<br>
		
		
			<!--menu -->
		
	<?php include_once ("menu.php");?>
		
		
		<!--menu -->
		
		
		
		</td>
		<td width="570" align="center" valign="top" id="mainarea3">
		
		
		
		
<div align="center">			
<br><TABLE  WIDTH=516 BORDER=0 CELLPADDING=0 CELLSPACING=0 align="center" valign="top">
	<TR>
		<TD WIDTH=516 HEIGHT=100% COLSPAN=6 id="allpages">	
<?
if (isset( $_SESSION['s_id']) || isset( $_SESSION['w_id']) )

		{
	
if(isset( $_SESSION['s_id']))
{
echo "<div id=artt>" ;
echo "مرحبا بك : " ;
echo "&nbsp;&nbsp;&nbsp;";
echo $_SESSION['s_name'] ;
echo "<br>" ;echo "<br>" ;
echo "<div align=center>" ;
echo "<a href=s_cp.php>";
echo "لوحة التحكم" ;
echo "</a>";
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

echo "<a href=logout.php>";
echo "تسجيل الخروج" ;
echo "</a>";
echo "</div>";
echo "<div>" ;
}

	
	
	if (isset( $_SESSION['w_id']))	
	
{
echo "<div id=artt>" ;
echo "مرحبا بك : " ;
echo "&nbsp;&nbsp;&nbsp;";
echo $_SESSION['w_name'] ;
echo "<br>" ;echo "<br>" ;
echo "<div align=center>" ;
echo "<a href=w_cp.php>";
echo "لوحة التحكم" ;
echo "</a>";
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

echo "<a href=logout.php>";
echo "تسجيل الخروج" ;
echo "</a>";
echo "</div>";
echo "<div>" ;
}




}

else

{

?>
<div id=artt>
مرحبا بك زائرنا الكريم
</div>
 <div id="artbb">
<p dir="rtl">أنت غير مسجل لدينا بالموقع يمكنك تسجيل الدخول بالموقع كمتدرب أو 
طالب وظيفة من خلال</p>
<p dir="rtl">- للدخول إلي&nbsp; الموقع كمتدرب<a href="student_login.php"> إضغط 
هنا </a>
أو للتسجيل كمتدرب جديد <a href="s_registration.php">&nbsp;إضغط هنا</a></p>
<p dir="rtl">- للدخول إلى الموقع كطالب وظيفه<a href="worker_login.php"> إضغط هنا
</a>&nbsp;أو للتسجيل كمتقدم جديد<a href="w_registration.php"> إضغط هنا</a></p>
</div>
<?
}
?>

</td></tr></table>

	</div>
	<br>