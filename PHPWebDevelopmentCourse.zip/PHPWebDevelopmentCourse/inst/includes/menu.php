<!-- rawan -->
<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr" >
		<tr>
			<td valign="top" height="100%" align="right">
<!-- ImageReady Slices (rawan.psd) -->





<div align="center">

<!-- ImageReady Slices (menu.psd) -->
<table  width="180" height="426" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="5">
			<img src="images/mainmenu/menu_01.gif" width="180" height="15" alt=""></td>
	</tr>
	<tr>
		<td colspan="5">
			<img src="images/mainmenu/menu_02.gif" width="180" height="46" alt=""></td>
	</tr>
	<tr>
		<td rowspan="13">
			<img src="images/mainmenu/menu_03.gif" width="26" height="314" alt=""></td>
		<td colspan="2">
			<a href="index.php"
				onmouseover="window.status='الصفحة الرئيسية';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_04.gif" width="114" height="26" border="0" alt="الصفحة الرئيسية"></a></td>
		<td colspan="2" rowspan="10">
			<img src="images/mainmenu/menu_05.gif" width="40" height="240" alt=""></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="admin.php"
				onmouseover="window.status='كلمة مدير المعهد';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_04-07.gif" width="114" height="23" border="0" alt="كلمة مدير المعهد"></a></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="about.php"
				onmouseover="window.status='تعرف علينا';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_06.gif" width="114" height="29" border="0" alt="تعرف علينا"></a></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="kader.php"
				onmouseover="window.status='الكادر الوظيفي';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_07.gif" width="114" height="27" border="0" alt="الكادر الوظيفي"></a></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="train.php"
				onmouseover="window.status='قسم الدورات';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_08.gif" width="114" height="27" border="0" alt="قسم الدورات"></a></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="view_jobs.php"
				onmouseover="window.status='قسم الوظائف';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_09.gif" width="114" height="25" border="0" alt="قسم الوظائف"></a></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="images/mainmenu/menu_11.gif" width="114" height="1" alt=""></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="news.php"
				onmouseover="window.status='قسم الأخبار';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_11-13.gif" width="114" height="25" border="0" alt="قسم الأخبار"></a></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="photos.php"
				onmouseover="window.status='معرض الصور';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_15.gif" width="114" height="28" border="0" alt="معرض الصور"></a></td>
	</tr>
	<tr>
		<td rowspan="3">
			<img src="images/mainmenu/menu_14.gif" width="1" height="80" alt=""></td>
		<td>
			<a href="sites.php"
				onmouseover="window.status='دليل المواقع';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_12.gif" width="113" height="29" border="0" alt="دليل المواقع"></a></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="solutions.php"
				onmouseover="window.status='الحلول التكنولوجية';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_13.gif" width="114" height="27" border="0" alt="الحلول التكنولوجية"></a></td>
		<td rowspan="3">
			<img src="images/mainmenu/menu_17.gif" width="39" height="74" alt=""></td>
	</tr>
	<tr>
		<td colspan="2">
			<a href="branches.php"
				onmouseover="window.status='فروعنا';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_16.gif" width="114" height="24" border="0" alt="فروعنا"></a></td>
	</tr>
	<tr>
		<td colspan="3">
			<a href="contactus.php"
				onmouseover="window.status='إتصل بنا';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_14-20.gif" width="115" height="23" border="0" alt="إتصل بنا"></a></td>
	</tr>
	<tr>
		<td colspan="5">
			<img src="images/mainmenu/menu_20.gif" width="180" height="50" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/mainmenu/spacer.gif" width="26" height="1" alt=""></td>
		<td>
			<img src="images/mainmenu/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="images/mainmenu/spacer.gif" width="113" height="1" alt=""></td>
		<td>
			<img src="images/mainmenu/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="images/mainmenu/spacer.gif" width="39" height="1" alt=""></td>
	</tr>
</table>
<!-- End ImageReady Slices -->

	
	
	
</div>


<!-- End ImageReady Slices -->
			</td>
		</tr>
	</table>
</div>



<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr" >
		<tr>
			<td valign="top" height="100%" align="right">
<!-- ImageReady Slices (rawan.psd) -->





<div align="center">
	<!-- ImageReady Slices (studient.psd) -->
	
	
<?


if (isset( $_SESSION['s_id'] ) )

		{
?>
<div align="center">


<!-- ImageReady Slices (print_info.psd) -->
<table  width="180" height="200" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="3">
			<img src="images/control/w/w_info_01.gif" width="180" height="54" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/control/w/w_info_02.gif" width="22" height="111" alt=""></td>
		<td width="139" height="111" align="center">
		
		<div id="arttitle">
			<?
			
 echo "مرحبا بك " ;
 echo "<br>";
 
echo $_SESSION['s_name'] ;

echo "<br>";
echo "<br>";
echo "<a href=s_cp.php>";
echo "لوحة التحكم" ;

echo "<br>";
echo "<br>";
echo "<a href=logout.php>";
echo "تسجيل الخروج" ;

	echo "</a>";



	echo "</a>";			
			?>
			</div>
			</td>
		<td>
			<img src="images/control/w/w_info_04.gif" width="19" height="111" alt=""></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/control/w/w_info_05.gif" width="180" height="35" alt=""></td>
	</tr>
</table>
<!-- End ImageReady Slices -->


</div>


<?

}

else

{
?>



<div align="center">
<!-- ImageReady Slices (workers.psd) -->
<table width="180" height="201" border="0" cellpadding="0" cellspacing="0">
<form name="s_login" method="post" action="student_login.php" target="_self">
	<tr>
		<td colspan="6">
			<img src="images/stu/stu_01.gif" width="180" height="71" alt=""></td>
	</tr>
	<tr>
		<td rowspan="4">
			<img src="images/stu/stu_02.gif" width="19" height="104" alt=""></td>
			
		<td colspan="3" width="141" height="29">
		<input name="stu_name" id="stu_name" size="17" maxlength="20" >
			
			</td>
		<td colspan="2" rowspan="3">
			<img src="images/stu/stu_04.gif" width="20" height="80" alt=""></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/stu/stu_05.gif" width="141" height="22" alt=""></td>
	</tr>
	<tr>
		<td colspan="3" width="141" height="29" >
		<input name="stu_pass" type=password id="stu_pass" size="17" maxlength="20">
		
			
			
			
			</td>
	</tr>
	<tr>
		<td width="44" height="24">
		
		<input border="0" type="image" src="images/stu/s_login.gif" name="s_login_ok" width="44" height="24" type="image" >
			
			
			</td>
		<td>
			<img src="images/workers/workers_08.gif" width="23" height="24" alt=""></td>
		<td colspan="2">
		<a href="s_registration.php" target="_self">
			<img src="images/stu/stu_09.gif" width="78" height="24" border="0"alt=""></td>
			</a>
		<td>
			<img src="images/stu/stu_10.gif" width="16" height="24" alt=""></td>
	</tr>
	<tr>
		<td colspan="6">
			<img src="images/stu/stu_11.gif" width="180" height="25" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/stu/spacer.gif" width="19" height="1" alt=""></td>
		<td>
			<img src="images/stu/spacer.gif" width="44" height="1" alt=""></td>
		<td>
			<img src="images/stu/spacer.gif" width="23" height="1" alt=""></td>
		<td>
			<img src="images/stu/spacer.gif" width="74" height="1" alt=""></td>
		<td>
			<img src="images/stu/spacer.gif" width="4" height="1" alt=""></td>
		<td>
			<img src="images/stu/spacer.gif" width="16" height="1" alt=""></td>
	</tr>
	</form>
</table>
<!-- End ImageReady Slices -->
</div>
<?
}
?>

<!-- End ImageReady Slices -->
<!-- End ImageReady Slices -->
</div>


<!-- End ImageReady Slices -->
			</td>
		</tr>
	</table>
</div>


<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr" >
		<tr>
			<td valign="top" height="100%" align="right">
<!-- ImageReady Slices (rawan.psd) -->


<?


if (isset( $_SESSION['w_id'] ) )

		{
?>
<div align="center">


<!-- ImageReady Slices (print_info.psd) -->
<table  width="180" height="200" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="3">
			<img src="images/control/w/w_info_01.gif" width="180" height="54" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/control/w/w_info_02.gif" width="22" height="111" alt=""></td>
		<td width="139" height="111" align="center">
		
		<div id="arttitle">
			<?
			
 echo "مرحبا بك " ;
 echo "<br>";
 
echo $_SESSION['w_name'] ;

echo "<br>";
echo "<br>";
echo "<a href=w_cp.php>";
echo "لوحة التحكم" ;

echo "<br>";
echo "<br>";
echo "<a href=logout.php>";
echo "تسجيل الخروج" ;

	echo "</a>";



	echo "</a>";			
			?>
			</div>
			</td>
		<td>
			<img src="images/control/w/w_info_04.gif" width="19" height="111" alt=""></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/control/w/w_info_05.gif" width="180" height="35" alt=""></td>
	</tr>
</table>
<!-- End ImageReady Slices -->


</div>


<?

}

else

{
?>



<div align="center">
<!-- ImageReady Slices (workers.psd) -->
<table width="180" height="201" border="0" cellpadding="0" cellspacing="0">
<form name="w_login" method="post" action="worker_login.php" target="_self">
	<tr>
		<td colspan="6">
			<img src="images/workers/workers_01.gif" width="180" height="71" alt=""></td>
	</tr>
	<tr>
		<td rowspan="4">
			<img src="images/workers/workers_02.gif" width="19" height="104" alt=""></td>
		<td colspan="3" width="141" height="29">
		<input name="worker_name" id="worker_name" size="17" maxlength="20" >
			
			</td>
		<td colspan="2" rowspan="3">
			<img src="images/workers/workers_04.gif" width="20" height="80" alt=""></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/workers/workers_05.gif" width="141" height="22" alt=""></td>
	</tr>
	<tr>
		<td colspan="3" width="141" height="29" >
		<input name="worker_pass" type=password id="worker_pass" size="17" maxlength="20">
		
			
			
			
			</td>
	</tr>
	<tr>
		<td width="44" height="24">
		<input border="0" type="image" src="images/workers/login.gif" name="w_login_ok" width="44" height="24" type="image" >
			
			
			</td>
		<td>
			<img src="images/workers/workers_08.gif" width="23" height="24" alt=""></td>
		<td colspan="2">
		<a href="w_registration.php" target="_self">
			<img src="images/workers/workers_09.gif" width="78" height="24" border="0"alt=""></td>
			</a>
		<td>
			<img src="images/workers/workers_10.gif" width="16" height="24" alt=""></td>
	</tr>
	<tr>
		<td colspan="6">
			<img src="images/workers/workers_11.gif" width="180" height="25" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/workers/spacer.gif" width="19" height="1" alt=""></td>
		<td>
			<img src="images/workers/spacer.gif" width="44" height="1" alt=""></td>
		<td>
			<img src="images/workers/spacer.gif" width="23" height="1" alt=""></td>
		<td>
			<img src="images/workers/spacer.gif" width="74" height="1" alt=""></td>
		<td>
			<img src="images/workers/spacer.gif" width="4" height="1" alt=""></td>
		<td>
			<img src="images/workers/spacer.gif" width="16" height="1" alt=""></td>
	</tr>
	</form>
</table>
<!-- End ImageReady Slices -->
</div>
<?
}
?>

<!-- End ImageReady Slices -->
			</td>
		</tr>
	</table>
</div>




<div align="center">
	<!-- ImageReady Slices (vists.psd) -->
<table  width="180" height="134" border="0" cellpadding="0" cellspacing="0" dir="ltr">
	<tr>
		<td colspan="3" width="180" height="33">
			<img src="images/vists/vists_01.gif" width="180" height="33" alt=""></td>
	</tr>
	<tr>
		<td width="22" height="82">
			<img src="images/vists/vists_02.gif" width="22" height="82" alt="">
			</td>
		<td width="141" height="82">
		<div id="arttitle">
			<?php include_once('online.php');?>
			</div>
			</td>
		<td width="17" height="82">
			<img src="images/vists/vists_04.gif" width="17" height="82" alt=""></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/vists/vists_05.gif" width="180" height="19" alt=""></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
</div>
<br>