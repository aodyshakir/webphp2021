</td>
		</tr>
	</table>
</div>

		</td>
		</tr>
	</table>
</div>
	<!--  copy-->
<table id="copy" align="center">
<td height="15" valign="top">

<div align="center" >
تصميم وبرمجة إدارة تقنية المعلومات والإنترنت بمعهد الجبيل الثقافي

</table>

	<!--  End copy-->

</body>
</html>
<?ob_end_flush();?>