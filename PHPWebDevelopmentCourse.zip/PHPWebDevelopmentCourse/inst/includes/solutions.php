<!-- rawan -->
<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr" >
		<tr>
			<td valign="top" height="100%" align="right">
<!-- ImageReady Slices (rawan.psd) -->





<div align="center">
	
	
	
	<!-- ImageReady Slices (menu.psd) -->
<table  width="180" height="360" border="0" cellpadding="0" cellspacing="0" dir="ltr">
	<tr>
		<td colspan="3">
			<img src="images/mainmenu/menu_01.gif" width="180" height="50" alt=""></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/mainmenu/menu_02.gif" width="180" height="18" alt=""></td>
	</tr>
	<tr>
		<td rowspan="10">
			<img src="images/mainmenu/menu_03.gif" width="26" height="247" alt=""></td>
		<td>
			<a href="admin.php"
				onmouseover="window.status='���� ���� ������';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_04.gif" width="114" height="23" border="0" alt="���� ���� ������"></a></td>
		<td rowspan="10">
			<img src="images/mainmenu/menu_05.gif" width="40" height="247" alt=""></td>
	</tr>
	<tr>
		<td>
			<a href="about.php"
				onmouseover="window.status='���� �����';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_06.gif" width="114" height="29" border="0" alt="���� �����"></a></td>
	</tr>
	<tr>
		<td>
			<a href="kader.php"
				onmouseover="window.status='������ �������';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_07.gif" width="114" height="27" border="0" alt="������ �������"></a></td>
	</tr>
	<tr>
		<td>
			<a href="train.php"
				onmouseover="window.status='��� �������';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_08.gif" width="114" height="27" border="0" alt="��� �������"></a></td>
	</tr>
	<tr>
		<td>
			<a href="jobs.php"
				onmouseover="window.status='��� �������';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_09.gif" width="114" height="25" border="0" alt="��� �������"></a></td>
	</tr>
	<tr>
		<td>
			<img src="images/mainmenu/menu_10.gif" width="114" height="1" alt=""></td>
	</tr>
	<tr>
		<td>
			<a href="news.php"
				onmouseover="window.status='��� �������';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_11.gif" width="114" height="25" border="0" alt="��� �������"></a></td>
	</tr>
	<tr>
		<td>
			<a href="sites.php"
				onmouseover="window.status='���� �������';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_12.gif" width="114" height="28" border="0" alt="���� �������"></a></td>
	</tr>
	<tr>
		<td>
			<a href="solutions.php"
				onmouseover="window.status='������ �����������';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_13.gif" width="114" height="30" border="0" alt="������ �����������"></a></td>
	</tr>
	<tr>
		<td>
			<a href="contactus.php"
				onmouseover="window.status='���� ���';  return true;"
				onmouseout="window.status='';  return true;">
				<img src="images/mainmenu/menu_14.gif" width="114" height="32" border="0" alt="���� ���"></a></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/mainmenu/menu_15.gif" width="180" height="45" alt=""></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
	
	
	
</div>


<!-- End ImageReady Slices -->
			</td>
		</tr>
	</table>
</div>



<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr" >
		<tr>
			<td valign="top" height="100%" align="right">
<!-- ImageReady Slices (rawan.psd) -->





<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr">
		<tr>
			<td>
			<img border="0" src="./images/studient.gif" width="180" height="200"></td>
		</tr>
	</table>
</div>


<!-- End ImageReady Slices -->
			</td>
		</tr>
	</table>
</div>


<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr" >
		<tr>
			<td valign="top" height="100%" align="right">
<!-- ImageReady Slices (rawan.psd) -->





<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr">
		<tr>
			<td>
			<img border="0" src="./images/workers.gif" width="180" height="200"></td>
		</tr>
	</table>
</div>


<!-- End ImageReady Slices -->
			</td>
		</tr>
	</table>
</div>
<!-- end rawan -->

<!-- zawaj-->

<div align="center">
	<table border="0" width="180" cellspacing="0" cellpadding="0" dir="ltr">
		<tr>
			<td>
			<img border="0" src="./images/vists.gif" width="180" height="134"></td>
		</tr>
	</table>
</div>

<!-- end zawaj -->

<!--- z3tr -->




<!-- end z3tr -->