<?include_once("includes/header.php");
session_destroy();
?>
<br><TABLE  WIDTH=516 HEIGHT=263 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD WIDTH=516 HEIGHT=100% COLSPAN=6 id="allpages">		
تم تسجيل الخروج بنجاح
	
</td></tr></table>
<? header("Location: index.php");?>

<?include_once("includes/footer.php"); ?>




