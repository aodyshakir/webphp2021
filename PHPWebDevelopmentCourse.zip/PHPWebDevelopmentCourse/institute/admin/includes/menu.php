<br>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
خيارات عامة</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="index.php">الرئيسية</a></td>
		</tr>	
		
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="logout.php">تسجيل الخروج</a></td>
		</tr>		
	</table>
</div>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
التحكم في الأقسام</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="addcat.php">إضافة قسم جديد</a></td>
		</tr>	
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewactivecat.php">عرض الأقسام المفعلة</a></td>
		</tr>	
		
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewinactivecat.php">عرض الأقسام غير المفعلة</a></td>
		</tr>	
		
	</table>
</div>
<br>


<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
التحكم في الدورات</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="addcat.php">إضافة دورة جديدة</a></td>
		</tr>	
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewactivecourse.php">عرض الدورات المفعلة</a></td>
		</tr>	
		
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewinactivecourse.php">عرض الدورات الغير مفعلة</a></td>
		</tr>	
		
	</table>
</div>
<br>


