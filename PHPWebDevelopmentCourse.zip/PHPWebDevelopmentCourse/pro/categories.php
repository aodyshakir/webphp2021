<?php
error_reporting(E_ALL);
include_once("header.php");?>


هنا يتم عرض أقسام المنتجات
<br />
<br />

<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />














<?php include_once("footer.php");?>