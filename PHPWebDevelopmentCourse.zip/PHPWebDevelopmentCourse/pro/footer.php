</div>

<div class="right">
<h2>أكثر المنتجات إستعراضاً</h2>
 
</div>

<div style="clear: both;"> </div>

</div>
<div id="bottom"> </div>
<div id="footer">
Developed by <a href="http://www.ahmeddahab.com/">Ahmed Abu_eldahab</a></div>

</div>
</body>
</html>