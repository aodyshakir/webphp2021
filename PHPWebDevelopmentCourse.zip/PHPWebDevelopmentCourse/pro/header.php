<?php
error_reporting(E_ALL);
include_once ("includes/config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl">
<head>
<title>معرض منتجات دهب</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />	
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="screen" />
	
	<script src="js/prototype.js" type="text/javascript"></script>
	<script src="js/scriptaculous.js?load=effects,builder" type="text/javascript"></script>
	<script src="js/lightbox.js" type="text/javascript"></script>
</head>
<body>
<div id="wrap">
<div id="header">
<h1><a href="#">معرض دهب</a></h1>
<h2>كل ما تحتاجه الأسرة المصرية</h2>
</div>

<div id="top"> </div>
<div id="contentt">
<div id="headermenu"> 
<div class="headerm">
<ul>
<li><a href="index.php">الرئيسية</a></li> 
<li><a href="#">نبذه عنا</a></li> 
<li><a href="#">خدماتنا</a></li> 
<li><a href="categories.php">معرض المنتجات</a></li>
<li><a href="#">إتصل بنا</a></li> 

</ul>
</div>
</div>

<div class="left">
<h2>أقسام الموقع</h2>
<ul>
<li>
قسم 
</li>

<li>
قسم 
</li>

<li>
قسم 
</li>

</ul>

<h2>أحدث المنتجات</h2>
<ul>
<li><a href="#">منتج</a></li> 

</ul>
</div>

<div class="middle">