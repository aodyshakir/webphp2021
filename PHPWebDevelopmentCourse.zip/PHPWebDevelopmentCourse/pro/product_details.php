<?php
include_once("header.php");?>


هنا تفاصيل المنتج
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />














<?php include_once("footer.php");?>


