<?php
$test = "this is my name";

//echo $test;

//$test=10;

echo $test."<br />";

$ahmed=5;

$value=$test+$ahmed;

echo $value."<br />";

$ss=10.34;
echo $ss."<br />";


$var= true;
echo $var."<br />";


$var2 = 7;

echo "this is var2 value:{$var2} ass";
?>