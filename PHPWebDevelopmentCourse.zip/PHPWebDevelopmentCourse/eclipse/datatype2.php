<?php
$var="this is my text";
echo str_ireplace("MY","***",$var);
//echo "<br />";
$var2=5;
$var6=6.65;
//echo gettype($var2);
//echo (int)$var2
$var7=((2+2)*$var2)/2+$var6;
//$var7 *=5;
//echo $var7;
//echo "<br />";
$var4=120;

echo $var;

//echo rand(1,5);

//echo ceil($var7);

?>