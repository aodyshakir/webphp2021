<?php
$var=5;
echo ceil($var);
echo "<br />";

echo floor($var);

echo "<br />";

echo round($var);

echo "<br />";

$var2="ahmed";
//echo md5($var2);

define("SIZE",400);


echo  SIZE;

$item = 4;
$Item=8;

echo $Item;
