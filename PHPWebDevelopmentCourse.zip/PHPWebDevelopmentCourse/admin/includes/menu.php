<br>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
خيارات عامة</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="index.php">الرئيسية</a></td>
		</tr>	
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="logout.php">تسجيل الخروج</a></td>
		</tr>		
	</table>
</div>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
القائمة العلوية</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
عناصر القائمة العلوية
			</td>
		</tr>
	
		
	
	</table>
</div>
<br>
