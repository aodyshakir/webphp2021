<br>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
خيارات عامة</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="index.php">الرئيسية</a></td>
		</tr>	
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="logout.php">تسجيل الخروج</a></td>
		</tr>		
	</table>
</div>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
القائمة العلوية</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewtopmenu.php">عرض القوائم</a></td>
		</tr>
	
		
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="addtopmenu.php">إضافة قائمة جديدة</a></td>
		</tr>
		
	
	</table>
</div>
<br>


<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
القائمة الجانبية</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewrightmenu.php">عرض القوائم</a></td>
		</tr>
	
		
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="addrightmenu.php">إضافة قائمة جديدة</a></td>
		</tr>
				
	</table>
</div>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
صفحات الموقع</td>
		</tr>
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="addpage.php">إضافة صفحة جديدة</a></td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewactivepages.php">عرض الصفحات المفعلة</a></td>
		</tr>
	
		
		<tr>
			<td valign="top" height="100%" id="menuadmin">
<a href="viewinactivepages.php">عرض الصفحات غير المفعلة</a></td>
		</tr>
		
		
			
	</table>
</div>
<br>



