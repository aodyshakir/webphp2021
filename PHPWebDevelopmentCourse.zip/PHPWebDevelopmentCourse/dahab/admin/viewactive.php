<?php
include_once ("includes/header.php");
include_once ("includes/config.php");
?>
<br />
<br />
<div align="right">
<h3> الردود المفعلة </h3>

</div>






















<?php
include_once ("includes/footer.php");
?>