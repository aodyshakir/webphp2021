<?
/*if($_SESSION['aa']=='1' )
{}
else{
header("Location: login.php");
exit;

}*/
?>